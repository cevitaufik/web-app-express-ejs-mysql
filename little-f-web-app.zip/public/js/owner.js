const owner = {
    linkInstagram : 'https://www.instagram.com/littlef.shop',
    linkShopee : 'https://shopee.co.id/novianti20?categoryId=33&itemId=9768666849',
    linkTokopedia : 'https://tokopedia.link/RePGkFiAZhb',
    whatsapp : '6289632943033',
    googleSheet : 'https://script.google.com/macros/s/AKfycbySp-ayFqNty1Gszg_oJOasD_FVzAbgTlclj8ZpOXUUIR-9DeNMguRhtDREx7_NFy59eQ/exec'
  }
